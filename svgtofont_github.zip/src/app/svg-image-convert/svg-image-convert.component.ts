import { Component, OnInit } from '@angular/core';
import { FileHandle } from '../directives/drag.directive';
import * as _ from 'lodash-es';
import { convert } from '../../assets/_svg_image_flatten.js'
import { SvgPath } from 'svgpath/lib/svgpath.js';
import * as xml from 'xml-js';
import { svg2ttf } from 'svg2ttf';
import * as b64 from 'base64-js';
import { ttf2woff } from 'ttf2woff';
import { ttf2eot } from 'ttf2eot';
import { JSZip } from 'jszip';
import { saveAs } from 'file-saver';

@Component({
    selector: 'app-svg-image-convert',
    templateUrl: './svg-image-convert.component.html',
    styleUrls: ['./svg-image-convert.component.css']
})
export class SvgImageConvertComponent implements OnInit {
    name = 'Angular 9';
    files: FileHandle[] = [];
    codepoint;
    fileSaveName: string;
    fontFam: string = "hubFont";
    glyphs: Array<any> = [];

    constructor() { }

    ngOnInit() {

    }

    filesDropped(files: FileHandle[], data) {
        for (let i = 0; i < files.length; i++) {
            if (files[i].file.type == "image/svg+xml") {
                console.log(files);
                const reader = new FileReader();
                reader.onload = (e) => {
                    this.import_svg_image(e['target']['result'], files[i].file);
                };
                reader.readAsText(files[i].file);
                this.files = files;
            }
            else {
                alert("Invalid Format");
            }
        }
    }

    import_svg_image(data, file) {
        // console.log(file, "file ===========");
        const result = convert(data);
        var matches = file.name.match(/^(?:u([0-9a-f]{4})\-)?(.*).svg$/i);
        let stringHexCount = 0;
        const fName = matches[2];
        let fileSaveName = fName;
        for (let i = 0; i < fName.length; i++) {
            const hex = (Number(fName.charCodeAt(i)).toString(16)).replace(/[aA-zZ]/g, '');
            stringHexCount = stringHexCount + parseInt(hex)
        }
        let codepoint = 'e' + stringHexCount;
        const skipped = _.union(result.ignoredTags, result.ignoredAttrs);
        const scale = 1000 / result.height;
        const d = new SvgPath(result.d).translate(-result.x, -result.y).scale(scale).abs().round(1).toString();
        const width = Math.round(result.width * scale);
        this.glyphs.push({
            d: d,
            width: width,
            code: codepoint,
            filename: fileSaveName
        })
        // this.makeSvgFont();
    }

    async makeSvgFont() {

        console.log(this.glyphs, "d and width===========");

        const conf = {};
        conf['font'] = {};
        conf['font']['fontname'] = 'icon';
        conf['font']['familyname'] = 'icon';
        conf['font'].ascent = 850;
        conf['font'].descent = conf['font'].ascent - 1000;
        conf['glyphs'] = _.map(this.glyphs, function (glyph) {
            return {
                css: 'icon',
                code: glyph.code,
                d: new SvgPath(glyph.d)
                    .scale(1, -1)
                    .translate(0, conf['font'].ascent)
                    .abs()
                    .round(1)
                    .toString(),
                width: glyph.width,
                filename: glyph.filename
            };
        });
        /* conf['glyphs'] = {
            css: 'icon',
            code: this.codepoint,
            d: new SvgPath(d).scale(1, -1).translate(0, conf['font'].ascent).abs().round(1).toString(),
            width: width
        } */
        console.log(conf['glyphs']);

        // this.downLoadFontFunction(d,width);

        var svgFontTemplate = _.template(
            '<?xml version="1.0" standalone="no"?>\n' +
            '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\n' +
            '<svg xmlns="http://www.w3.org/2000/svg">\n' +
            '<defs>\n' +
            '<font id="_${font.fontname}" horiz-adv-x="${font.ascent - font.descent}" >\n' +
            '<font-face' +
            ' font-family="${font.familyname}"' +
            ' font-weight="400"' +
            ' font-stretch="normal"' +
            ' units-per-em="${font.ascent - font.descent}"' +
            ' ascent="${font.ascent}"' +
            ' descent="${font.descent}"' +
            ' />\n' +

            '<missing-glyph horiz-adv-x="${font.ascent - font.descent}" />\n' +

            '<% glyphs.forEach(function(glyph) { %>' +
            '<glyph' +
            ' glyph-name="${glyph.css}"' +
            ' unicode="&#x${glyph.code};"' +
            ' d="${glyph.d}"' +
            ' horiz-adv-x="${glyph.width}"' +
            ' />\n' +
            '<% }); %>' +

            '</font>\n' +
            '</defs>\n' +
            '</svg>'
        );

        console.log(svgFontTemplate(conf))

        var ttf = svg2ttf(svgFontTemplate(conf)).buffer;
        const base64ttf = 'data:font/truetype;base64,' + b64.fromByteArray(ttf);
        let ttf2eotOutput = ttf2eot(ttf).buffer;
        let woffOutput = ttf2woff(ttf).buffer;

        var zip = new JSZip();
        var fontZip = zip.folder("font");

        //svg file created
        fontZip.file("hubFornt.svg", svgFontTemplate(conf));

        // ttf file created
        fontZip.file("hubFornt.ttf", ttf);

        // eot file created
        fontZip.file("hubFornt.eot", ttf2eotOutput);

        // woff output file
        fontZip.file("hubFornt.woff2", woffOutput);
        console.log(zip, "+++++++++++");


        // Dynamic css created
        var fontZip = zip.folder("css");

        // animation.css created
        let animateCss = ".animate - spin { -moz - animation: spin 2s infinite linear;-o - animation: spin 2s infinite linear;-webkit - animation: spin 2s infinite linear;animation: spin 2s infinite linear;display: inline - block;}" +
            "@-moz-keyframes spin { 0% { -moz-transform: rotate(0deg);-o-transform: rotate(0deg);-webkit-transform: rotate(0deg);transform: rotate(0deg);}" +
            "100% {-moz-transform: rotate(359deg);-o-transform: rotate(359deg);-webkit-transform: rotate(359deg);transform: rotate(359deg);}}" +
            "@-webkit-keyframes spin { 0% {-moz-transform: rotate(0deg);-o-transform: rotate(0deg); -webkit-transform: rotate(0deg);transform: rotate(0deg);}" +
            "100% {-moz-transform: rotate(359deg);-o-transform: rotate(359deg);-webkit-transform: rotate(359deg);transform: rotate(359deg);}}" +
            "@-o-keyframes spin {0% {-moz-transform: rotate(0deg);-o-transform: rotate(0deg);-webkit-transform: rotate(0deg);transform: rotate(0deg);}" +
            "100% {-moz-transform: rotate(359deg); -o-transform: rotate(359deg);-webkit-transform: rotate(359deg);transform: rotate(359deg);}}" +
            "@-ms-keyframes spin {0% { -moz-transform: rotate(0deg);-o-transform: rotate(0deg);-webkit-transform: rotate(0deg);transform: rotate(0deg);}" +
            "100% {-moz-transform: rotate(359deg);-o-transform: rotate(359deg);-webkit-transform: rotate(359deg);transform: rotate(359deg);}}" +
            "@keyframes spin { 0% { -moz-transform: rotate(0deg);-o-transform: rotate(0deg);-webkit-transform: rotate(0deg);transform: rotate(0deg);}" +
            "100% {-moz-transform: rotate(359deg);-o-transform: rotate(359deg);-webkit-transform: rotate(359deg); transform: rotate(359deg);}}"

        fontZip.file("animation.css", animateCss);

        // hubFont.css created 

        let hubFontCss = _.template(
            "@font-face {font-family: " + this.fontFam + "; src: url('../font/icons.eot?87713699'); " +
            // "src: url('../font/icons.eot?87713699#iefix') format('embedded-opentype')," +
            // "url('../font/icons.woff?87713699')" +
            // "format('woff'),url('../font/icons.ttf?87713699')" +
            // "format('truetype'),url('../font/icons.svg?87713699#icons') format('svg');" +
            "font-weight: normal;font-style: normal;}" +
            "[class^='icon-']:before, [class*='icon-']:before {font-family: " + this.fontFam + ";font-style: normal;font-weight: normal;speak: none;display: inline-block;" +
            "text-decoration: inherit;width: 1em;margin-right: .2em; text-align: center;\n" +
            "font-variant: normal; text-transform: none;line-height: 1em;margin-left: .2em;}\n<% glyphs.forEach(function(glyph) { %>.icon-${glyph.filename}:before { content: '\\${glyph.code}';}\n<% }); %>"
        );

        fontZip.file("hubFont.css", hubFontCss(conf));

        // // hubFont-codes.css file created
        let fontCode = _.template(
            "<% glyphs.forEach(function(glyph) { %>.icon-${glyph.filename}:before { content: '\\${glyph.code}';}\n<% }); %>"
        );
        fontZip.file("hubFont-codes.css", fontCode(conf));

        // // hubFont-ie7.css
        let hubFontIe7 = _.template(
            "[class^='icon-'],[class*='icon-']\n { font-family:" + this.fontFam + ";font-style: normal;font-weight: normal;line-height: 1em;}\n" +
            "<% glyphs.forEach(function(glyph) { %>.icon-${glyph.filename}{ *zoom: expression( this.runtimeStyle['zoom'] = '1', this.innerHTML = '&#x${glyph.code}';}\n<% }); %>");

        fontZip.file("hubFont-ie7.css", hubFontIe7(conf));

        // // hubFont-ie7-codes.css file created
        let ie7Codes = _.template(
            "<% glyphs.forEach(function(glyph) { %>.icon-${glyph.filename}{ *zoom: expression( this.runtimeStyle['zoom'] = '1', this.innerHTML = '&#x${glyph.code}';}\n<% }); %>");

        fontZip.file("hubFont-ie7-codes.css", ie7Codes(conf));

        // // hubFont-embedded.css
        let hubEmbed = _.template("@font-face {font-family:" + this.fontFam + ";src: url('../font/" + this.fontFam + ".eot?67284563');src: url('../font/" + this.fontFam + ".eot?67284563#iefix') format('embedded-opentype')," +
            "url('../font/" + this.fontFam + ".svg?67284563#" + this.fontFam + "') format('svg');font-weight: normal;font-style: normal;}" +
            "[class^='icon-']:before, [class*='icon-']:before { font-family: " + this.fontFam + ";font-style: normal;font-weight: normal;speak: none;" +
            "display: inline-block;text-decoration: inherit; width: 1em;margin-right: .2em;text-align: center;font-variant: normal;text-transform: none;" +
            "line-height: 1em;margin-left: .2em; }\n" +
            "<% glyphs.forEach(function(glyph) { %>.icon-${glyph.filename}:before { content: '\\${glyph.code}';}\n<% }); %>"
        );

        fontZip.file("hubFont-embedded.css", hubEmbed(conf));


        zip.generateAsync({ type: "blob" })
            .then(function (content) {
                saveAs(content, "hubFont.zip");
            });
    };




    downLoadFontFunction(d, width) {

    }

}

