import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SvgImageConvertComponent } from './svg-image-convert.component';

describe('SvgImageConvertComponent', () => {
  let component: SvgImageConvertComponent;
  let fixture: ComponentFixture<SvgImageConvertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SvgImageConvertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SvgImageConvertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
