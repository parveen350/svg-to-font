import { PreloadingStrategy, Route } from '@angular/router';
import { Observable, of, timer } from 'rxjs';
import { Injectable } from '@angular/core';
import { flatMap } from 'rxjs/operators';

@Injectable()
export class CustomPreloadingStrategy implements PreloadingStrategy {
    preload(route: Route, load: Function): Observable<any> {
        const preload = (data: any) => data.delay ? timer(data.delayTime).pipe(flatMap(() => load())): load();
        return route.data && route.data.preload ? preload(route.data) : of(null);
    }
}
