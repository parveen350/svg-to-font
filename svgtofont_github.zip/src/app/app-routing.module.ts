import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomPreloadingStrategy } from './custom-preloading-strategy';


const routes: Routes = [
  {
    path: 'parent',
    loadChildren: () => import('./parent/parent.module').then(mod => mod.ParentModule),
    data: {preload: true, delay: true, delayTime: 3000}
  },
  {
    path: 'child',
    loadChildren: () => import('./child/child.module').then(mod => mod.ChildModule),
    data: {preload: true, delay: true, delayTime: 1500}
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {preloadingStrategy: CustomPreloadingStrategy})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
