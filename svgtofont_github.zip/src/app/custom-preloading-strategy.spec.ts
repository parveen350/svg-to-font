import { CustomPreloadingStrategy } from './custom-preloading-strategy';

describe('CustomPreloadingStrategy', () => {
  it('should create an instance', () => {
    expect(new CustomPreloadingStrategy()).toBeTruthy();
  });
});
