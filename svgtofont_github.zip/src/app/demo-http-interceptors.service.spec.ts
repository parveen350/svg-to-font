import { TestBed } from '@angular/core/testing';

import { DemoHttpInterceptorsService } from './demo-http-interceptors.service';

describe('DemoHttpInterceptorsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DemoHttpInterceptorsService = TestBed.get(DemoHttpInterceptorsService);
    expect(service).toBeTruthy();
  });
});
