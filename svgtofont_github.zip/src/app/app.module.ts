import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { PerfumeModule } from 'perfume.js/angular'
import { DemoHttpInterceptorsService } from './demo-http-interceptors.service';
import { ModalComponent } from './modal/modal.component';
import { ModalService } from './modal.service';
import { CustomPreloadingStrategy } from './custom-preloading-strategy';
import { AnalyticsTrackerService } from './services/analytics-tracker.service';
import { CachingService } from './services/caching.service';
import { SvgImageConvertComponent } from './svg-image-convert/svg-image-convert.component';
import { DragDirective } from './directives/drag.directive';

export const PerfumeConfig = {
  firstPaint: true,
  networkInformation: true,
  navigationTiming: true,
  firstContentfulPaint: true,
  firstInputDelay: true,
  dataConsumption: true,
  largestContentfulPaint: true,
  resourceTiming: true,
  logPrefix: 'Perfume.js',
  logging: false,
  analyticsTracker: options => { },
  googleAnalytics: {
    enable: false,
    timingVar: 'name'
  }
}

export const multiHttpInterceptors = [
  { provide: HTTP_INTERCEPTORS, useClass: DemoHttpInterceptorsService, multi: true }
]

@NgModule({
  declarations: [
    AppComponent,
    SvgImageConvertComponent,
    DragDirective,
    ModalComponent
  ],
  imports: [
    PerfumeModule.forRoot(PerfumeConfig),
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  exports: [DragDirective],
  providers: [AnalyticsTrackerService, multiHttpInterceptors, ModalService, CustomPreloadingStrategy, AnalyticsTrackerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
