import { Component, OnInit, Input, ElementRef, OnDestroy, ViewEncapsulation, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ModalService } from '../modal.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ModalComponent implements OnInit, OnChanges, OnDestroy {
  @Input() id: string;
  @Input() index: string;
  @Input() count: number;
  @Output() userId = new EventEmitter<any>();
  private element: any;
  constructor(private modalService: ModalService, private el: ElementRef) {
    this.element = el.nativeElement;
  }

  ngOnInit() {
    if (!this.id) {
      return;
    }
    document.body.appendChild(this.element);
    this.element.addEventListener('click', el => {
      if (el.target.className === 'jw-modal') {
        this.close();
      }
    })
    this.modalService.add(this);
  }

  ngOnChanges(value: SimpleChanges) {
    console.log('simplechanges === ', value.index);
  }

  open(): void {
    this.element.style.display = 'block';
    document.body.classList.add('jw-modal-open');
  }

  close(): void {
    this.element.style.display = 'none';
    document.body.classList.remove('jw-modal-open');
  }

  ngOnDestroy() {
    this.modalService.remove(this.id);
    this.element.remove();
  }

  closeModal(id: string) {
    this.userId.next('1');
    this.modalService.close(id);
  }

}
