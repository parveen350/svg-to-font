import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CachingService {
  private request: any = {};
  constructor() {
    console.log('constructor initialized')
  }

  put(url: string, response: HttpResponse<any>) {
    this.request[url] = response;
  }

  get(url: string): HttpResponse<any> {
    return this.request[url];
  }

  invalidateCache() {
    this.request = {};
  }

}
