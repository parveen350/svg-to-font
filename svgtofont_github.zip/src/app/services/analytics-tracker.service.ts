import { Injectable } from '@angular/core';
import { NgPerfume } from 'perfume.js/angular';

@Injectable({
  providedIn: 'root'
})
export class AnalyticsTrackerService {

  private analiticsTrakerList: any[] = [];

  constructor(private perfume: NgPerfume) {
    this.perfume.config.analyticsTracker = ({ metricName, data, duration, eventProperties, navigatorInformation }) => {
      switch (metricName) {
        case 'resourceTiming':
          console.log('resourceTiming = ', data);
          break;
        case 'dataConsumption':
          // console.log('dataConsumption = ', data);
          break;
        case 'openDialog':
          // console.log('openDialog == ', data);
          break;
        case 'executionTime':
          // console.log('executionTime = ', data);
          break;
        default:
          break;
      }
    }
  }

  setData(type, id, startTime, EndTime) {

  }

  getData() {
    return this.analiticsTrakerList;
  }

}
