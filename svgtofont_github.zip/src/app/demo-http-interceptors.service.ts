import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { CachingService } from './services/caching.service';

@Injectable({
  providedIn: 'root'
})
export class DemoHttpInterceptorsService implements HttpInterceptor {
  constructor(private cacheService: CachingService, private response: Response) { }
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const reqM = req.clone({setHeaders: {'Content-type' : 'application/json'}});
    return next.handle(reqM);
  }
}
