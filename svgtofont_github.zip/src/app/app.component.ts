import { HttpClient, HttpErrorResponse, HttpEvent } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgPerfume, PerfumeAfterViewInit } from 'perfume.js/angular';
import { Observable, throwError } from 'rxjs';
import { catchError, shareReplay, retry } from 'rxjs/operators';
import { ModalService } from './modal.service';
import { AnalyticsTrackerService } from './services/analytics-tracker.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit {
  title = 'Demo';
  count = 0;
  baseUrl: string = 'http://142.93.223.49:8080/yooflix/rest/'
  @ViewChild('username', { static: false }) username: ElementRef;
  methodsList = {
    'getVideos': () => `${this.baseUrl}user/getPlayListVideos`,
    'getSubscribedChannel': () => `${this.baseUrl}user/getNotification`
  }
  employeeData: Array<any> = [{ name: 'John', id: 1 }, { name: 'Michael', id: 2 }, { name: 'James', id: 3 }];
  constructor(private http: HttpClient, private perfume: NgPerfume, private modalService: ModalService,
    private analiticsTraker: AnalyticsTrackerService) {
    this.perfume.start('app-component');
    this.modalService.counter(0);
    // this.modalService.observable.subscribe((res) => console.log(res));
    /* this.modalService.observable.subscribe((res) => {
      console.log(res);
    }) */
  }

  ngOnInit() {
    this.callFn1(1, 'getVideos');

    /* this.observableIntervalFn().subscribe(res => {
      console.log('data = ', getSubscribedChannelres);
    })

    this.promiseIntervalFn().then(res => {
      console.log('data = ', res);
    }); */
  }

  promiseIntervalFn() {
    return new Promise(resolve => {
      setInterval(() => {
        resolve(new Date().toString());
      }, 1000);
    })
  }

  observableIntervalFn() {
    return new Observable<string>(observer => {
      setInterval(() => {
        observer.next(new Date().toString());
      }, 1000)
    })
  }

  ngAfterViewInit(): void {
    this.perfume.endPaint('app-component');
    // console.log(this.username.nativeElement.value);
  }

  getHeroes(ajaxVal, data): Observable<HttpEvent<any>> {
    const reqUrl = this.methodsList[ajaxVal]();
    return this.http.post(reqUrl, data).pipe(catchError(this.handleError()));
  }

  dummyCal(val, ajaxVal) {
    this.getHeroes(ajaxVal, { userPK: val }).subscribe(res => {
      console.log('res == ', res);
    });
  }

  callFn1(val, ajaxVal) {
    this.perfume.start('executionTime');
    this.dummyCal(val, ajaxVal);
    this.perfume.end('executionTime');
  }

  handleError() {
    return (error: HttpErrorResponse): Observable<any> => {
      if (error.error instanceof ErrorEvent) {
        // console.log(error.error.message);
      } else {
        // console.log(error);
      }
      return throwError('Something bad happened! please try again later');
    }
  }

  openModal(id: string) {
    this.perfume.start('openDialog');
    this.modalService.open(id);
    this.perfume.endPaint('openDialog');
  }

  closeModal(id: string) {
    this.modalService.close(id);
  }

  getUserId(id) {
    // console.log(id);
  }

  updateCount() {
    this.count++;
  }

}